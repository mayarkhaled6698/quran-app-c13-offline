import 'package:flutter/material.dart';
import 'package:islami_c13_offline/my_app.dart';

void main() {
  runApp(const IslamiApp());
}
