import 'package:flutter/material.dart';

class PrayTimesTab extends StatelessWidget {
  const PrayTimesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.lightBlue,
    );
  }
}
