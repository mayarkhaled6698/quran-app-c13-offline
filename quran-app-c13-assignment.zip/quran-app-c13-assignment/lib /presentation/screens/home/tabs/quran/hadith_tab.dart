import 'package:flutter/material.dart';
import 'package:islami_c13_offline/core/resources/assets_manager.dart';

class HadithTab extends StatelessWidget {
  const HadithTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Placeholder();
  }
}
